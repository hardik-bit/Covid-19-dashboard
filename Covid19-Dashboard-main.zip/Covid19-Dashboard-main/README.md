# Covid19-Dashboard

Requirements : Kindly install the following packages from `pip install <package>`

`pip install matplotlib`
`pip install urllib`
`pip install webbrowser`
`pip install shutil`

Just run the makesite.py file to host a local website.
